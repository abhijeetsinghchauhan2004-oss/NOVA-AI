# NOVA AI

NOVA AI is a Python desktop voice-assistant project. The current prototype uses a Tkinter interface, microphone input, speech recognition, PIN-based login, and a local SQLite database.

> **Project status:** Early development / prototype. The repository currently contains the core Python application. It is not yet a one-click installer.

## Current features

- Wake phrase detection: "Hello Nova" or "Hey Nova"
- PIN-based login and account registration
- Local SQLite storage for users, sessions, and voice-command history
- Voice commands for time, date, Notepad, Calculator, and YouTube
- Tkinter desktop interface

## Requirements

- Python 3.13 recommended
- A working microphone
- Internet connection for Google speech recognition (`recognize_google`)
- Windows currently supported by the built-in Notepad and Calculator commands

The speech recognition service sends recorded speech to Google's recognition service. This prototype is therefore **not fully offline**.

## Run from source (Windows)

1. Install Python 3.13.
2. Install Git (optional, only needed to clone/update the repository).
3. Clone this repository:

   ```bash
   git clone https://github.com/abhijeetsinghchauhan2004-oss/NOVA-AI.git
   cd NOVA-AI
   ```

4. Create and activate a virtual environment:

   ```powershell
   py -3.13 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

5. Install dependencies:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

6. Start NOVA:

   ```powershell
   python main.py
   ```

On first use, say "Hello Nova" or "Hey Nova", then choose **New user? Create Account** to register a local account.

## Database and privacy

- The application uses SQLite through Python's built-in `sqlite3` module.
- The database is stored locally on the device (not in GitHub).
- Do not commit database files, passwords, API keys, recordings, or personal information.
- The old `desko_ai_database.sql` MySQL schema is not needed to run the current SQLite prototype and should not be uploaded.

## Build a Windows executable (developer instructions)

Install the application dependencies and PyInstaller, then run:

```powershell
pip install pyinstaller
pyinstaller --noconfirm --clean --windowed --name "NOVA AI" main.py
```

The executable output is placed in `dist/`. Test it on a clean Windows account before distributing it.

## macOS status

A macOS build must be created and tested on macOS. Before advertising macOS support, the app still needs macOS-specific Notepad/Calculator alternatives, microphone-permission testing, and packaging validation. PyAudio may require PortAudio on macOS:

```bash
brew install portaudio
python3 -m pip install -r requirements.txt
```

## Roadmap

- [ ] Complete Windows testing and packaging
- [ ] Add and test macOS-specific application commands
- [ ] Validate local database initialization and account registration
- [ ] Add installer and release notes
- [ ] Add automated tests and offline speech recognition option

## Contributing

Issues and pull requests are welcome. Please do not include personal data, database files, credentials, or private recordings in issues or commits.

## License

No open-source license has been selected yet. Until a license is added, the repository is published for viewing but reuse and redistribution are not automatically granted.
