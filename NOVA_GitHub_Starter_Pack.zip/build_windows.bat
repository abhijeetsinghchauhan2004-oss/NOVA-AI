@echo off
setlocal
py -3.13 -m pip install --upgrade pip
py -3.13 -m pip install -r requirements.txt
py -3.13 -m pip install pyinstaller
py -3.13 -m PyInstaller --noconfirm --clean --windowed --name "NOVA AI" main.py
echo.
echo Build complete. Check the dist folder.
pause
