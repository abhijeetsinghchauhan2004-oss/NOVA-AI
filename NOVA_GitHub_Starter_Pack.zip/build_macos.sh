#!/bin/bash
set -euo pipefail
python3 -m pip install --upgrade pip
brew install portaudio
python3 -m pip install -r requirements.txt
python3 -m pip install pyinstaller
python3 -m PyInstaller --noconfirm --clean --windowed --name "NOVA AI" main.py
echo "Build complete. Check the dist folder."
